# FRUITMC — Premium Minecraft Store

Modern, fully responsive Minecraft server store website built with **Next.js**, **React**, **Tailwind CSS**.

## Features

- **Premium dark theme** with fruit-inspired gradients (green, orange, red, purple) and glassmorphism
- **Homepage** with hero, live server IP + copy button, featured packages, ranks preview, Discord CTA, reviews
- **Store categories**: Ranks (VIP → KING), Crates, Coins, Special Items
- **Product cards** with discounts, details modal, add-to-cart
- **Shopping cart** with quantity management
- **Checkout** with Razorpay-ready flow (demo simulated payment)
- **Success / Failed** payment pages
- **User accounts** — login/register, Minecraft username linking, order history
- **Admin panel** (password: `adminfruitmcpass`)
  - Add / edit / delete products
  - Change prices & discounts
  - View all orders
- **Support** — FAQ accordion + ticket form
- **Responsive** navbar, mobile menu, live server status
- Data persisted in `localStorage` (demo mode)

## Quick Start

```bash
cd fruitmc-store
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Admin Access

1. Go to `/admin`
2. Password: **`adminfruitmcpass`**
3. Manage products, prices, and view orders

## Production Notes

### Razorpay Integration
1. Create a Razorpay account and get `key_id` + `key_secret`
2. Add a backend API route (e.g. `/api/create-order`) that creates a Razorpay order
3. On the checkout page, open Razorpay Checkout with the order ID
4. Verify the payment signature on the server
5. Trigger Minecraft delivery (plugin / RCON / database queue)

**Never store card details.** Razorpay handles PCI compliance.

### Minecraft Delivery
Use a plugin such as:
- Buycraft / Tebex (external)
- Custom plugin listening to a database/Redis queue
- RCON commands after verified payment

### Recommended Stack for Production
- Next.js (this frontend)
- PostgreSQL + Prisma for products, users, orders
- NextAuth or Clerk for real authentication
- Razorpay webhooks for reliable delivery
- Redis for rate-limiting and queues

## Project Structure

```
src/
  app/           # App Router pages
  components/    # Navbar, Footer, ProductCard, CopyIP
  context/       # StoreContext (cart, products, auth, admin)
  lib/           # types, initial products data
```

## Customization

- Products & prices: edit via Admin panel or `src/lib/products.ts`
- Theme colors: `src/app/globals.css`
- Server IP: `SERVER_IP` in `src/lib/products.ts`
- Admin password: `ADMIN_PASSWORD` in `src/lib/products.ts`

---

© FruitMC. Not affiliated with Mojang / Microsoft.
