"use client";

import { useState } from "react";
import { SERVER_IP } from "@/lib/products";

export default function CopyIP({ className = "" }: { className?: string }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(SERVER_IP);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
      const el = document.createElement("textarea");
      el.value = SERVER_IP;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <button
      onClick={copy}
      className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl glass border border-purple-500/40 hover:border-purple-400/60 transition-all group ${className}`}
    >
      <span className="w-2 h-2 rounded-full status-online animate-pulse" />
      <span className="font-mono text-sm sm:text-base text-green-400 font-medium">{SERVER_IP}</span>
      <span className={`text-xs font-medium transition-colors ${copied ? "text-green-400" : "text-gray-400 group-hover:text-purple-300"}`}>
        {copied ? "Copied!" : "Copy"}
      </span>
    </button>
  );
}
