"use client";

import Link from "next/link";
import { SERVER_IP, DISCORD_URL } from "@/lib/products";

export default function Footer() {
  return (
    <footer className="border-t border-purple-500/20 bg-[#08060f] mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🍇</span>
              <span className="text-xl font-bold">
                <span className="fruit-gradient-text">FRUIT</span>
                <span className="text-white">MC</span>
              </span>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">
              Premium Minecraft network. Unlock exclusive ranks, crates and rewards.
            </p>
            <div className="flex items-center gap-2 text-sm">
              <span className="w-2 h-2 rounded-full status-online" />
              <span className="text-green-400 font-medium">{SERVER_IP}</span>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Store</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link href="/ranks" className="hover:text-purple-300 transition">Ranks</Link></li>
              <li><Link href="/crates" className="hover:text-purple-300 transition">Crates</Link></li>
              <li><Link href="/store" className="hover:text-purple-300 transition">All Products</Link></li>
              <li><Link href="/cart" className="hover:text-purple-300 transition">Cart</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Support</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link href="/support" className="hover:text-purple-300 transition">Help Center</Link></li>
              <li><Link href="/about" className="hover:text-purple-300 transition">About Us</Link></li>
              <li><Link href="/support#faq" className="hover:text-purple-300 transition">FAQ</Link></li>
              <li><Link href="/support#tickets" className="hover:text-purple-300 transition">Tickets</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Community</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <a href={DISCORD_URL} target="_blank" rel="noopener noreferrer" className="hover:text-purple-300 transition flex items-center gap-2">
                  <span>💬</span> Discord
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-purple-300 transition flex items-center gap-2">
                  <span>🐦</span> Twitter / X
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-purple-300 transition flex items-center gap-2">
                  <span>▶️</span> YouTube
                </a>
              </li>
              <li>
                <Link href="/admin" className="hover:text-orange-300 transition text-xs text-gray-500">
                  Admin
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-500">
          <p>© {new Date().getFullYear()} FruitMC. All rights reserved.</p>
          <p className="text-center">Not affiliated with Mojang or Microsoft. Minecraft is a trademark of Mojang Studios.</p>
        </div>
      </div>
    </footer>
  );
}
