"use client";

import { useState } from "react";
import { Product } from "@/lib/types";
import { useStore } from "@/context/StoreContext";

interface Props {
  product: Product;
}

export default function ProductCard({ product }: Props) {
  const { addToCart } = useStore();
  const [showDetails, setShowDetails] = useState(false);
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    addToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <>
      <div className="glass rounded-2xl overflow-hidden card-hover group relative">
        {product.popular && (
          <div className="absolute top-3 left-3 z-10 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg">
            Popular
          </div>
        )}
        {product.discount > 0 && (
          <div className="absolute top-3 right-3 z-10 px-2.5 py-1 rounded-full text-[10px] font-bold bg-green-500/90 text-white">
            -{product.discount}%
          </div>
        )}

        {/* Image */}
        <div className="product-img h-36 sm:h-40 relative overflow-hidden">
          <span className="text-5xl sm:text-6xl group-hover:scale-110 transition-transform duration-500">
            {product.image}
          </span>
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f]/80 to-transparent opacity-60" />
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 space-y-3">
          <div>
            <h3 className="text-lg font-bold text-white group-hover:text-purple-300 transition-colors">
              {product.name}
            </h3>
            <p className="text-xs text-gray-400 mt-1 line-clamp-2 leading-relaxed">
              {product.description}
            </p>
          </div>

          <div className="flex items-end justify-between gap-2">
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-xl font-bold text-white">₹{product.price}</span>
                {product.originalPrice > product.price && (
                  <span className="text-sm text-gray-500 line-through">₹{product.originalPrice}</span>
                )}
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleAdd}
              className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 ${
                added
                  ? "bg-green-600 text-white"
                  : "btn-primary text-white"
              }`}
            >
              {added ? "✓ Added" : "Buy Now"}
            </button>
            <button
              onClick={() => setShowDetails(true)}
              className="px-3 py-2.5 rounded-xl glass border border-purple-500/30 text-purple-300 hover:bg-purple-500/20 transition text-sm"
              aria-label="Details"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Details Modal */}
      {showDetails && (
        <div
          className="fixed inset-0 z-[100] modal-overlay flex items-center justify-center p-4"
          onClick={() => setShowDetails(false)}
        >
          <div
            className="glass-strong rounded-2xl max-w-md w-full p-6 space-y-5 shadow-2xl border border-purple-500/30"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <span className="text-4xl">{product.image}</span>
                <div>
                  <h3 className="text-xl font-bold text-white">{product.name}</h3>
                  <p className="text-xs text-purple-400 uppercase tracking-wider">{product.category}</p>
                </div>
              </div>
              <button
                onClick={() => setShowDetails(false)}
                className="p-1.5 rounded-lg hover:bg-white/10 text-gray-400"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <p className="text-sm text-gray-300 leading-relaxed">{product.description}</p>

            {product.features && product.features.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold text-purple-300 uppercase tracking-wider mb-2">Features</h4>
                <ul className="space-y-1.5">
                  {product.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-gray-300">
                      <span className="text-green-400">✓</span> {f}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex items-center justify-between pt-2 border-t border-white/10">
              <div>
                <span className="text-2xl font-bold text-white">₹{product.price}</span>
                {product.originalPrice > product.price && (
                  <span className="ml-2 text-sm text-gray-500 line-through">₹{product.originalPrice}</span>
                )}
              </div>
              <button
                onClick={() => {
                  handleAdd();
                  setShowDetails(false);
                }}
                className="btn-primary px-6 py-2.5 rounded-xl text-sm font-semibold text-white"
              >
                Add to Cart
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
