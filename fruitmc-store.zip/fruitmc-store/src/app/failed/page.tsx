"use client";

import Link from "next/link";

export default function FailedPage() {
  return (
    <div className="max-w-md mx-auto px-4 py-20 text-center space-y-6">
      <div className="w-20 h-20 mx-auto rounded-full bg-red-500/20 flex items-center justify-center text-4xl">
        ✕
      </div>
      <h1 className="text-2xl font-bold text-white">Payment Failed</h1>
      <p className="text-gray-400 text-sm leading-relaxed">
        Something went wrong with the payment. No charges were made. You can try again or contact support.
      </p>
      <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
        <Link href="/checkout" className="btn-primary px-6 py-3 rounded-xl text-white text-sm font-semibold">
          Try Again
        </Link>
        <Link href="/support" className="glass px-6 py-3 rounded-xl text-gray-300 text-sm font-medium hover:bg-white/5">
          Contact Support
        </Link>
      </div>
    </div>
  );
}
