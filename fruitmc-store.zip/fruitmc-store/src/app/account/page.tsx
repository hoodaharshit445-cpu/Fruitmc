"use client";

import { useRouter } from "next/navigation";
import { useStore } from "@/context/StoreContext";
import Link from "next/link";

export default function AccountPage() {
  const { user, logout, orders } = useStore();
  const router = useRouter();

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <p className="text-gray-400">Please login to view your account.</p>
        <Link href="/login" className="text-purple-400 hover:underline text-sm">
          Login
        </Link>
      </div>
    );
  }

  const userOrders = orders.filter(
    (o) => o.username.toLowerCase() === user.username.toLowerCase()
  );

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Account</h1>
          <p className="text-sm text-gray-400 mt-0.5">Manage your FruitMC profile</p>
        </div>
        <button
          onClick={() => {
            logout();
            router.push("/");
          }}
          className="text-sm text-red-400 hover:text-red-300"
        >
          Logout
        </button>
      </div>

      <div className="glass rounded-2xl p-6 mb-8 space-y-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-purple-600/30 flex items-center justify-center text-xl">
            🎮
          </div>
          <div>
            <p className="font-semibold text-white">{user.username}</p>
            <p className="text-xs text-gray-400">{user.email}</p>
          </div>
        </div>
        <p className="text-xs text-gray-500 pt-2 border-t border-white/5">
          Minecraft username is linked for automatic delivery of purchases.
        </p>
      </div>

      <h2 className="text-lg font-semibold text-white mb-4">Order History</h2>
      {userOrders.length === 0 ? (
        <div className="glass rounded-2xl p-8 text-center text-gray-500 text-sm">
          No orders yet.{" "}
          <Link href="/store" className="text-purple-400 hover:underline">
            Browse the store
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {userOrders.map((order) => (
            <div key={order.id} className="glass rounded-xl p-4 space-y-2">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-mono text-sm text-purple-300">{order.id}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(order.createdAt).toLocaleString()}
                  </p>
                </div>
                <span
                  className={`text-xs px-2 py-0.5 rounded-full ${
                    order.status === "completed"
                      ? "bg-green-500/20 text-green-400"
                      : order.status === "failed"
                      ? "bg-red-500/20 text-red-400"
                      : "bg-yellow-500/20 text-yellow-400"
                  }`}
                >
                  {order.status}
                </span>
              </div>
              <div className="text-sm text-gray-300">
                {order.items.map((i) => (
                  <span key={i.product.id} className="mr-2">
                    {i.product.image} {i.product.name} ×{i.quantity}
                  </span>
                ))}
              </div>
              <p className="text-sm font-semibold text-white">₹{order.total}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
