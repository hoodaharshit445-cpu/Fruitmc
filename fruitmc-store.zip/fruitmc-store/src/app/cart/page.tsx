"use client";

import Link from "next/link";
import { useStore } from "@/context/StoreContext";

export default function CartPage() {
  const { cart, removeFromCart, updateQuantity, cartTotal, clearCart } = useStore();

  if (cart.length === 0) {
    return (
      <div className="max-w-lg mx-auto px-4 py-20 text-center space-y-4">
        <span className="text-5xl">🛒</span>
        <h1 className="text-2xl font-bold text-white">Your cart is empty</h1>
        <p className="text-gray-400 text-sm">Browse the store and add some ranks or crates!</p>
        <Link href="/store" className="inline-block btn-primary px-6 py-3 rounded-xl text-white font-semibold text-sm mt-2">
          Explore Store
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-white">Shopping Cart</h1>
        <button onClick={clearCart} className="text-xs text-red-400 hover:text-red-300">
          Clear all
        </button>
      </div>

      <div className="space-y-4 mb-8">
        {cart.map((item) => (
          <div key={item.product.id} className="glass rounded-2xl p-4 flex gap-4 items-center">
            <div className="w-16 h-16 rounded-xl product-img shrink-0 text-2xl">
              {item.product.image}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-white truncate">{item.product.name}</h3>
              <p className="text-xs text-gray-400">₹{item.product.price} each</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                className="w-8 h-8 rounded-lg glass flex items-center justify-center text-gray-300 hover:bg-white/10"
              >
                −
              </button>
              <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
              <button
                onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                className="w-8 h-8 rounded-lg glass flex items-center justify-center text-gray-300 hover:bg-white/10"
              >
                +
              </button>
            </div>
            <div className="text-right min-w-[70px]">
              <p className="font-semibold text-white">₹{item.product.price * item.quantity}</p>
              <button
                onClick={() => removeFromCart(item.product.id)}
                className="text-[10px] text-red-400 hover:underline"
              >
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="glass rounded-2xl p-6 space-y-4">
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Subtotal</span>
          <span className="text-white font-medium">₹{cartTotal}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Delivery</span>
          <span className="text-green-400">Instant (in-game)</span>
        </div>
        <div className="border-t border-white/10 pt-4 flex justify-between">
          <span className="font-semibold text-white">Total</span>
          <span className="text-xl font-bold text-white">₹{cartTotal}</span>
        </div>
        <Link
          href="/checkout"
          className="block w-full btn-primary py-3.5 rounded-xl text-white font-semibold text-center text-sm"
        >
          Proceed to Checkout
        </Link>
      </div>
    </div>
  );
}
