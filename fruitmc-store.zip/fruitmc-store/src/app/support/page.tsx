"use client";

import { useState } from "react";
import { DISCORD_URL } from "@/lib/products";

const faqs = [
  {
    q: "How long does delivery take?",
    a: "Most purchases are delivered automatically within 1–2 minutes after successful payment. If delayed, open a ticket or message us on Discord.",
  },
  {
    q: "What payment methods are accepted?",
    a: "We accept UPI, cards, netbanking and wallets through Razorpay. We never store your card details.",
  },
  {
    q: "Can I gift a rank to a friend?",
    a: "Yes — enter their Minecraft username at checkout. The rank will be applied to their account.",
  },
  {
    q: "I paid but didn't receive my items",
    a: "Check your Minecraft username spelling first. Then open a support ticket with your payment ID. We resolve most cases within a few hours.",
  },
  {
    q: "Are ranks permanent?",
    a: "Yes, all ranks are permanent unless stated otherwise on the product page.",
  },
];

export default function SupportPage() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [ticket, setTicket] = useState({ name: "", email: "", subject: "", message: "" });
  const [sent, setSent] = useState(false);

  const submitTicket = (e: React.FormEvent) => {
    e.preventDefault();
    // In production this would hit an API / Discord webhook
    setSent(true);
    setTicket({ name: "", email: "", subject: "", message: "" });
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2 text-center">
        Support <span className="fruit-gradient-text">Center</span>
      </h1>
      <p className="text-gray-400 text-center mb-10">FAQ, tickets and community help</p>

      {/* Discord CTA */}
      <div className="glass rounded-2xl p-5 mb-10 flex flex-col sm:flex-row items-center justify-between gap-4 border border-indigo-500/30">
        <div>
          <p className="font-semibold text-white">Fastest support on Discord</p>
          <p className="text-sm text-gray-400">Most questions answered in under 15 minutes</p>
        </div>
        <a
          href={DISCORD_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="px-5 py-2.5 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] text-white text-sm font-semibold transition shrink-0"
        >
          Join Discord
        </a>
      </div>

      {/* FAQ */}
      <section id="faq" className="mb-12">
        <h2 className="text-xl font-bold text-white mb-4">Frequently Asked Questions</h2>
        <div className="space-y-2">
          {faqs.map((faq, i) => (
            <div key={i} className="glass rounded-xl overflow-hidden">
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                className="w-full flex items-center justify-between px-5 py-4 text-left text-sm font-medium text-white hover:bg-white/5 transition"
              >
                {faq.q}
                <span className="text-purple-400 text-lg">{openFaq === i ? "−" : "+"}</span>
              </button>
              {openFaq === i && (
                <div className="px-5 pb-4 text-sm text-gray-400 leading-relaxed">{faq.a}</div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Ticket form */}
      <section id="tickets">
        <h2 className="text-xl font-bold text-white mb-4">Open a Support Ticket</h2>
        {sent ? (
          <div className="glass rounded-2xl p-8 text-center space-y-3">
            <span className="text-4xl">✅</span>
            <p className="text-white font-semibold">Ticket submitted!</p>
            <p className="text-sm text-gray-400">We&apos;ll reply to your email shortly. For faster help, also ping us on Discord.</p>
            <button onClick={() => setSent(false)} className="text-sm text-purple-400 hover:underline">
              Submit another
            </button>
          </div>
        ) : (
          <form onSubmit={submitTicket} className="glass rounded-2xl p-6 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-gray-400 mb-1.5">Minecraft Username</label>
                <input
                  required
                  value={ticket.name}
                  onChange={(e) => setTicket({ ...ticket, name: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm focus:outline-none focus:border-purple-400"
                  placeholder="YourIgn"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1.5">Email</label>
                <input
                  required
                  type="email"
                  value={ticket.email}
                  onChange={(e) => setTicket({ ...ticket, email: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm focus:outline-none focus:border-purple-400"
                  placeholder="you@email.com"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1.5">Subject</label>
              <input
                required
                value={ticket.subject}
                onChange={(e) => setTicket({ ...ticket, subject: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm focus:outline-none focus:border-purple-400"
                placeholder="Payment issue / Delivery delay..."
              />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1.5">Message</label>
              <textarea
                required
                rows={4}
                value={ticket.message}
                onChange={(e) => setTicket({ ...ticket, message: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm focus:outline-none focus:border-purple-400 resize-none"
                placeholder="Describe your issue and include payment ID if relevant..."
              />
            </div>
            <button type="submit" className="btn-primary w-full py-3 rounded-xl text-white font-semibold text-sm">
              Submit Ticket
            </button>
          </form>
        )}
      </section>
    </div>
  );
}
