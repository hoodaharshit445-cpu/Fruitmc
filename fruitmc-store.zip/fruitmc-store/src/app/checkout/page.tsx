"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/context/StoreContext";
import Link from "next/link";

export default function CheckoutPage() {
  const { cart, cartTotal, clearCart, addOrder, user } = useStore();
  const router = useRouter();
  const [username, setUsername] = useState(user?.username || "");
  const [email, setEmail] = useState(user?.email || "");
  const [loading, setLoading] = useState(false);

  if (cart.length === 0) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <p className="text-gray-400">Your cart is empty.</p>
        <Link href="/store" className="text-purple-400 hover:underline text-sm">
          Go to store
        </Link>
      </div>
    );
  }

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;
    setLoading(true);

    // Simulate Razorpay flow
    // In production:
    // 1. Call backend to create Razorpay order
    // 2. Open Razorpay checkout with key_id + order_id
    // 3. On success, verify signature on backend and deliver to Minecraft

    await new Promise((r) => setTimeout(r, 1500));

    // Mock success (90% chance) for demo
    const success = Math.random() > 0.1;

    if (success) {
      const order = {
        id: `ORD-${Date.now()}`,
        items: [...cart],
        total: cartTotal,
        status: "completed" as const,
        username: username.trim(),
        createdAt: new Date().toISOString(),
        paymentId: `pay_${Math.random().toString(36).slice(2, 12)}`,
      };
      addOrder(order);
      clearCart();
      router.push(`/success?order=${order.id}&user=${encodeURIComponent(username)}`);
    } else {
      router.push("/failed");
    }
    setLoading(false);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-10">
      <h1 className="text-2xl sm:text-3xl font-bold text-white mb-8">Checkout</h1>

      <div className="grid gap-6">
        {/* Order summary */}
        <div className="glass rounded-2xl p-5 space-y-3">
          <h2 className="font-semibold text-white text-sm uppercase tracking-wider text-gray-400">
            Order Summary
          </h2>
          {cart.map((item) => (
            <div key={item.product.id} className="flex justify-between text-sm">
              <span className="text-gray-300">
                {item.product.image} {item.product.name} × {item.quantity}
              </span>
              <span className="text-white">₹{item.product.price * item.quantity}</span>
            </div>
          ))}
          <div className="border-t border-white/10 pt-3 flex justify-between font-semibold">
            <span className="text-white">Total</span>
            <span className="text-xl text-white">₹{cartTotal}</span>
          </div>
        </div>

        {/* Delivery details */}
        <form onSubmit={handlePay} className="glass rounded-2xl p-6 space-y-4">
          <h2 className="font-semibold text-white text-sm uppercase tracking-wider text-gray-400">
            Delivery Details
          </h2>
          <div>
            <label className="block text-xs text-gray-400 mb-1.5">Minecraft Username *</label>
            <input
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm focus:outline-none focus:border-purple-400"
              placeholder="Exact in-game username"
            />
            <p className="text-[11px] text-gray-500 mt-1">Items will be delivered to this account automatically</p>
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1.5">Email (receipt)</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm focus:outline-none focus:border-purple-400"
              placeholder="you@email.com"
            />
          </div>

          <div className="pt-2">
            <p className="text-xs text-gray-500 mb-3 flex items-center gap-1.5">
              <span>🔒</span> Secure payment via Razorpay · We never store card details
            </p>
            <button
              type="submit"
              disabled={loading}
              className="w-full btn-primary py-3.5 rounded-xl text-white font-semibold text-sm disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Processing...
                </>
              ) : (
                `Pay ₹${cartTotal} with Razorpay`
              )}
            </button>
          </div>
        </form>

        <p className="text-center text-[11px] text-gray-600">
          Demo mode: payment is simulated. Connect real Razorpay keys + backend for production.
        </p>
      </div>
    </div>
  );
}
