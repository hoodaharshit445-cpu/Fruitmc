"use client";

import ProductCard from "@/components/ProductCard";
import { useStore } from "@/context/StoreContext";

export default function RanksPage() {
  const { products } = useStore();
  const ranks = products.filter((p) => p.category === "ranks");

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="text-center mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold text-white">
          Premium <span className="fruit-gradient-text">Ranks</span>
        </h1>
        <p className="text-gray-400 mt-2 max-w-lg mx-auto">
          From VIP to KING — unlock exclusive perks, cosmetics and priority features on FruitMC.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {ranks.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}
