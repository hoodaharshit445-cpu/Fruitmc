"use client";

import Link from "next/link";
import CopyIP from "@/components/CopyIP";
import ProductCard from "@/components/ProductCard";
import { useStore } from "@/context/StoreContext";
import { DISCORD_URL } from "@/lib/products";

export default function HomePage() {
  const { products } = useStore();
  const featured = products.filter((p) => p.popular).slice(0, 4);
  const ranks = products.filter((p) => p.category === "ranks").slice(0, 3);

  return (
    <div className="relative">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-20 left-10 w-72 h-72 bg-purple-600/20 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-green-500/10 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-orange-500/5 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20 md:pt-24 md:pb-28">
          <div className="text-center space-y-6 max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass border border-purple-500/30 text-sm text-purple-300">
              <span className="w-2 h-2 rounded-full status-online animate-pulse" />
              Server Online · play.fruitmc.fun
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black tracking-tight leading-tight">
              <span className="fruit-gradient-text">UPGRADE</span>
              <br />
              <span className="text-white">YOUR GAME.</span>
            </h1>

            <p className="text-base sm:text-lg text-gray-400 max-w-xl mx-auto leading-relaxed">
              Unlock exclusive ranks, perks and rewards on FruitMC.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <Link
                href="/store"
                className="btn-primary px-8 py-3.5 rounded-xl text-white font-semibold text-base shadow-lg shadow-purple-900/40 w-full sm:w-auto text-center"
              >
                Explore Store
              </Link>
              <a
                href="#join"
                className="btn-secondary px-8 py-3.5 rounded-xl text-white font-semibold text-base w-full sm:w-auto text-center"
              >
                Join Server
              </a>
            </div>

            <div id="join" className="pt-6 flex justify-center">
              <CopyIP />
            </div>
          </div>
        </div>
      </section>

      {/* Banner offer */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-4 mb-16">
        <div className="glass rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row items-center justify-between gap-4 border border-orange-500/30 bg-gradient-to-r from-orange-500/10 via-red-500/5 to-purple-500/10">
          <div className="flex items-center gap-3">
            <span className="text-3xl">🔥</span>
            <div>
              <p className="font-bold text-white">Limited Time Offer</p>
              <p className="text-sm text-gray-400">Up to 35% off on all ranks & crates this week</p>
            </div>
          </div>
          <Link
            href="/store"
            className="px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-400 text-white text-sm font-semibold transition shrink-0"
          >
            Shop Now →
          </Link>
        </div>
      </section>

      {/* Featured packages */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white">Featured Packages</h2>
            <p className="text-sm text-gray-400 mt-1">Most popular upgrades chosen by players</p>
          </div>
          <Link href="/store" className="text-sm text-purple-400 hover:text-purple-300 font-medium hidden sm:block">
            View all →
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {featured.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Ranks preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white">Premium Ranks</h2>
            <p className="text-sm text-gray-400 mt-1">Climb the hierarchy and unlock powerful perks</p>
          </div>
          <Link href="/ranks" className="text-sm text-purple-400 hover:text-purple-300 font-medium hidden sm:block">
            All ranks →
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {ranks.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Server info + Discord */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="glass rounded-2xl p-6 sm:p-8 space-y-4">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <span>ℹ️</span> Server Info
            </h3>
            <ul className="space-y-3 text-sm text-gray-300">
              <li className="flex justify-between">
                <span className="text-gray-500">IP</span>
                <span className="font-mono text-green-400">play.fruitmc.fun</span>
              </li>
              <li className="flex justify-between">
                <span className="text-gray-500">Version</span>
                <span>1.20 – 1.21</span>
              </li>
              <li className="flex justify-between">
                <span className="text-gray-500">Modes</span>
                <span>Survival · Skyblock · Mini-games</span>
              </li>
              <li className="flex justify-between">
                <span className="text-gray-500">Players</span>
                <span className="text-green-400">Online now</span>
              </li>
            </ul>
            <CopyIP className="w-full justify-center mt-2" />
          </div>

          <div className="glass rounded-2xl p-6 sm:p-8 space-y-4 border border-indigo-500/30 bg-gradient-to-br from-indigo-500/10 to-transparent">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <span>💬</span> Join the Community
            </h3>
            <p className="text-sm text-gray-400 leading-relaxed">
              Get support, announce purchases, join events and chat with thousands of FruitMC players on Discord.
            </p>
            <a
              href={DISCORD_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] text-white font-semibold text-sm transition w-full sm:w-auto justify-center"
            >
              Join Discord
            </a>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <h2 className="text-2xl font-bold text-white mb-6 text-center">What Players Say</h2>
        <div className="grid sm:grid-cols-3 gap-5">
          {[
            { name: "Steve_Builder", text: "Best ranks I've bought. Instant delivery and cool perks!", stars: 5 },
            { name: "AlexPvP", text: "Legendary crate gave me an epic pet. Worth every rupee.", stars: 5 },
            { name: "CraftyQueen", text: "Support is super fast on Discord. Highly recommend FruitMC.", stars: 5 },
          ].map((r, i) => (
            <div key={i} className="glass rounded-2xl p-5 space-y-3">
              <div className="flex text-yellow-400 text-sm">{"★".repeat(r.stars)}</div>
              <p className="text-sm text-gray-300 leading-relaxed">&ldquo;{r.text}&rdquo;</p>
              <p className="text-xs text-purple-400 font-medium">— {r.name}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
