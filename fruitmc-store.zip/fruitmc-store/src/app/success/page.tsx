"use client";

import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Suspense } from "react";

function SuccessContent() {
  const params = useSearchParams();
  const orderId = params.get("order") || "—";
  const user = params.get("user") || "player";

  return (
    <div className="max-w-md mx-auto px-4 py-20 text-center space-y-6">
      <div className="w-20 h-20 mx-auto rounded-full bg-green-500/20 flex items-center justify-center text-4xl pulse-glow">
        ✓
      </div>
      <h1 className="text-2xl font-bold text-white">Payment Successful!</h1>
      <p className="text-gray-400 text-sm leading-relaxed">
        Your order <span className="text-purple-300 font-mono">{orderId}</span> has been confirmed.
        Items are being delivered to <span className="text-green-400 font-medium">{user}</span> on the server.
      </p>
      <div className="glass rounded-xl p-4 text-left text-sm space-y-2">
        <p className="text-gray-400">What happens next?</p>
        <ul className="space-y-1.5 text-gray-300">
          <li>✓ Automatic delivery via our Minecraft plugin</li>
          <li>✓ Check in-game for ranks / crates / coins</li>
          <li>✓ Receipt sent to your email (if provided)</li>
        </ul>
      </div>
      <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
        <Link href="/account" className="btn-primary px-6 py-3 rounded-xl text-white text-sm font-semibold">
          View Orders
        </Link>
        <Link href="/store" className="glass px-6 py-3 rounded-xl text-gray-300 text-sm font-medium hover:bg-white/5">
          Continue Shopping
        </Link>
      </div>
    </div>
  );
}

export default function SuccessPage() {
  return (
    <Suspense fallback={<div className="py-20 text-center text-gray-400">Loading...</div>}>
      <SuccessContent />
    </Suspense>
  );
}
