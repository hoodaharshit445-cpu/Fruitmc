"use client";

import { useState } from "react";
import ProductCard from "@/components/ProductCard";
import { useStore } from "@/context/StoreContext";
import { categoryLabels } from "@/lib/products";
import { Category as CatType } from "@/lib/types";

const categories: (CatType | "all")[] = ["all", "ranks", "crates", "coins", "special"];

export default function StorePage() {
  const { products } = useStore();
  const [active, setActive] = useState<CatType | "all">("all");

  const filtered =
    active === "all" ? products : products.filter((p) => p.category === active);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="text-center mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold text-white">
          <span className="fruit-gradient-text">Store</span>
        </h1>
        <p className="text-gray-400 mt-2">Browse ranks, crates, coins and exclusive items</p>
      </div>

      {/* Category tabs */}
      <div className="flex flex-wrap justify-center gap-2 mb-10">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActive(cat)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              active === cat
                ? "bg-purple-600 text-white shadow-lg shadow-purple-900/40"
                : "glass text-gray-300 hover:bg-white/5"
            }`}
          >
            {cat === "all" ? "All" : categoryLabels[cat]}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {filtered.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>

      {filtered.length === 0 && (
        <p className="text-center text-gray-500 py-20">No products in this category yet.</p>
      )}
    </div>
  );
}
