"use client";

import ProductCard from "@/components/ProductCard";
import { useStore } from "@/context/StoreContext";

export default function CratesPage() {
  const { products } = useStore();
  const crates = products.filter((p) => p.category === "crates");

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="text-center mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold text-white">
          Mystery <span className="fruit-gradient-text">Crates</span>
        </h1>
        <p className="text-gray-400 mt-2 max-w-lg mx-auto">
          Open crates for coins, cosmetics, pets and rare rank upgrades. Higher tiers = better odds.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {crates.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}
