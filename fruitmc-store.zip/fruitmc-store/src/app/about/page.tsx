export default function AboutPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl sm:text-4xl font-bold text-white mb-6">
        About <span className="fruit-gradient-text">FruitMC</span>
      </h1>
      <div className="glass rounded-2xl p-6 sm:p-8 space-y-5 text-gray-300 leading-relaxed">
        <p>
          FruitMC is a premium Minecraft network built for players who want more than the basics.
          We run Survival, Skyblock and exciting mini-games with a focus on fairness, performance and community.
        </p>
        <p>
          Our store powers exclusive ranks, crates and cosmetics that are delivered instantly to your in-game account.
          All purchases support server development, new features and events.
        </p>
        <p>
          Join thousands of players on <span className="text-green-400 font-mono">play.fruitmc.fun</span> and
          upgrade your experience today.
        </p>
        <div className="pt-4 border-t border-white/10">
          <h3 className="text-white font-semibold mb-2">Our Promise</h3>
          <ul className="space-y-2 text-sm">
            <li>✓ Instant delivery after successful payment</li>
            <li>✓ Secure payments via Razorpay (no card data stored)</li>
            <li>✓ Active Discord support team</li>
            <li>✓ Regular events and new content</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
