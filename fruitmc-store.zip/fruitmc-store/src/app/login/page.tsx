"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/context/StoreContext";

export default function LoginPage() {
  const { login, user } = useStore();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [mode, setMode] = useState<"login" | "register">("login");

  if (user) {
    router.push("/account");
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !username) return;
    login(email, username);
    router.push("/account");
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="text-center mb-8">
        <span className="text-4xl">🍇</span>
        <h1 className="text-2xl font-bold text-white mt-3">
          {mode === "login" ? "Welcome back" : "Create account"}
        </h1>
        <p className="text-sm text-gray-400 mt-1">
          Link your Minecraft username for instant delivery
        </p>
      </div>

      <form onSubmit={handleSubmit} className="glass rounded-2xl p-6 space-y-4">
        <div>
          <label className="block text-xs text-gray-400 mb-1.5">Email</label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm focus:outline-none focus:border-purple-400"
            placeholder="you@email.com"
          />
        </div>
        <div>
          <label className="block text-xs text-gray-400 mb-1.5">Minecraft Username</label>
          <input
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm focus:outline-none focus:border-purple-400"
            placeholder="YourIgn"
          />
        </div>
        <button type="submit" className="btn-primary w-full py-3 rounded-xl text-white font-semibold text-sm">
          {mode === "login" ? "Login" : "Register"}
        </button>
        <p className="text-center text-xs text-gray-500">
          {mode === "login" ? (
            <>
              New here?{" "}
              <button type="button" onClick={() => setMode("register")} className="text-purple-400 hover:underline">
                Create an account
              </button>
            </>
          ) : (
            <>
              Already have an account?{" "}
              <button type="button" onClick={() => setMode("login")} className="text-purple-400 hover:underline">
                Login
              </button>
            </>
          )}
        </p>
      </form>

      <p className="text-center text-xs text-gray-600 mt-6">
        By continuing you agree to our terms. Demo auth — no real backend password.
      </p>
    </div>
  );
}
