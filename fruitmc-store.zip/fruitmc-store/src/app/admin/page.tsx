"use client";

import { useState } from "react";
import { useStore } from "@/context/StoreContext";
import { Product, Category } from "@/lib/types";
import { categoryLabels } from "@/lib/products";

export default function AdminPage() {
  const {
    isAdmin,
    adminLogin,
    adminLogout,
    products,
    updateProduct,
    deleteProduct,
    addProduct,
    orders,
  } = useStore();

  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [tab, setTab] = useState<"products" | "orders" | "add">("products");
  const [editing, setEditing] = useState<Product | null>(null);

  // New product form
  const [newProd, setNewProd] = useState<Partial<Product>>({
    name: "",
    description: "",
    category: "ranks",
    price: 99,
    originalPrice: 149,
    discount: 0,
    image: "🍇",
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminLogin(password)) {
      setError("");
      setPassword("");
    } else {
      setError("Incorrect password");
    }
  };

  const saveEdit = () => {
    if (editing) {
      const disc =
        editing.originalPrice > editing.price
          ? Math.round(((editing.originalPrice - editing.price) / editing.originalPrice) * 100)
          : 0;
      updateProduct({ ...editing, discount: disc });
      setEditing(null);
    }
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProd.name || !newProd.price) return;
    const disc =
      (newProd.originalPrice || 0) > (newProd.price || 0)
        ? Math.round(
            (((newProd.originalPrice || 0) - (newProd.price || 0)) / (newProd.originalPrice || 1)) *
              100
          )
        : 0;
    addProduct({
      id: `custom-${Date.now()}`,
      name: newProd.name!,
      description: newProd.description || "",
      category: (newProd.category as Category) || "special",
      price: Number(newProd.price),
      originalPrice: Number(newProd.originalPrice) || Number(newProd.price),
      discount: disc,
      image: newProd.image || "🎁",
      features: [],
    });
    setNewProd({
      name: "",
      description: "",
      category: "ranks",
      price: 99,
      originalPrice: 149,
      discount: 0,
      image: "🍇",
    });
    setTab("products");
  };

  if (!isAdmin) {
    return (
      <div className="max-w-sm mx-auto px-4 py-20">
        <div className="text-center mb-6">
          <span className="text-3xl">🔐</span>
          <h1 className="text-xl font-bold text-white mt-2">Admin Login</h1>
          <p className="text-xs text-gray-500 mt-1">Authorized personnel only</p>
        </div>
        <form onSubmit={handleLogin} className="glass rounded-2xl p-6 space-y-4">
          <div>
            <label className="block text-xs text-gray-400 mb-1.5">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm focus:outline-none focus:border-purple-400"
              placeholder="Enter admin password"
              autoFocus
            />
          </div>
          {error && <p className="text-red-400 text-xs">{error}</p>}
          <button type="submit" className="btn-primary w-full py-3 rounded-xl text-white font-semibold text-sm">
            Login
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
          <p className="text-sm text-gray-400">Manage products, prices and orders</p>
        </div>
        <button
          onClick={adminLogout}
          className="text-sm text-red-400 hover:text-red-300 self-start"
        >
          Logout Admin
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 flex-wrap">
        {(["products", "orders", "add"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition ${
              tab === t
                ? "bg-purple-600 text-white"
                : "glass text-gray-300 hover:bg-white/5"
            }`}
          >
            {t === "products" ? "Products" : t === "orders" ? "Orders" : "Add Product"}
          </button>
        ))}
      </div>

      {/* Products tab */}
      {tab === "products" && (
        <div className="space-y-3">
          {products.map((p) => (
            <div key={p.id} className="glass rounded-xl p-4 flex flex-col sm:flex-row sm:items-center gap-3">
              {editing?.id === p.id ? (
                <div className="flex-1 grid sm:grid-cols-2 gap-3 w-full">
                  <input
                    value={editing.name}
                    onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                    className="px-3 py-2 rounded-lg bg-black/40 border border-purple-500/30 text-white text-sm"
                    placeholder="Name"
                  />
                  <input
                    value={editing.image}
                    onChange={(e) => setEditing({ ...editing, image: e.target.value })}
                    className="px-3 py-2 rounded-lg bg-black/40 border border-purple-500/30 text-white text-sm"
                    placeholder="Emoji"
                  />
                  <input
                    type="number"
                    value={editing.price}
                    onChange={(e) => setEditing({ ...editing, price: Number(e.target.value) })}
                    className="px-3 py-2 rounded-lg bg-black/40 border border-purple-500/30 text-white text-sm"
                    placeholder="Price"
                  />
                  <input
                    type="number"
                    value={editing.originalPrice}
                    onChange={(e) =>
                      setEditing({ ...editing, originalPrice: Number(e.target.value) })
                    }
                    className="px-3 py-2 rounded-lg bg-black/40 border border-purple-500/30 text-white text-sm"
                    placeholder="Original"
                  />
                  <textarea
                    value={editing.description}
                    onChange={(e) => setEditing({ ...editing, description: e.target.value })}
                    className="sm:col-span-2 px-3 py-2 rounded-lg bg-black/40 border border-purple-500/30 text-white text-sm"
                    rows={2}
                    placeholder="Description"
                  />
                  <div className="sm:col-span-2 flex gap-2">
                    <button
                      onClick={saveEdit}
                      className="px-4 py-2 rounded-lg bg-green-600 text-white text-sm font-medium"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setEditing(null)}
                      className="px-4 py-2 rounded-lg glass text-gray-300 text-sm"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <span className="text-2xl">{p.image}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-white truncate">{p.name}</p>
                    <p className="text-xs text-gray-400">
                      {categoryLabels[p.category]} · ₹{p.price}
                      {p.discount > 0 && (
                        <span className="text-green-400 ml-1">(-{p.discount}%)</span>
                      )}
                    </p>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <button
                      onClick={() => setEditing(p)}
                      className="px-3 py-1.5 rounded-lg glass text-xs text-purple-300 hover:bg-purple-500/20"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Delete ${p.name}?`)) deleteProduct(p.id);
                      }}
                      className="px-3 py-1.5 rounded-lg glass text-xs text-red-400 hover:bg-red-500/20"
                    >
                      Delete
                    </button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Orders tab */}
      {tab === "orders" && (
        <div className="space-y-3">
          {orders.length === 0 ? (
            <p className="text-gray-500 text-sm text-center py-10">No orders yet.</p>
          ) : (
            orders.map((o) => (
              <div key={o.id} className="glass rounded-xl p-4 space-y-2">
                <div className="flex justify-between">
                  <span className="font-mono text-sm text-purple-300">{o.id}</span>
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      o.status === "completed"
                        ? "bg-green-500/20 text-green-400"
                        : "bg-red-500/20 text-red-400"
                    }`}
                  >
                    {o.status}
                  </span>
                </div>
                <p className="text-sm text-gray-300">
                  Player: <span className="text-white">{o.username}</span> · ₹{o.total}
                </p>
                <p className="text-xs text-gray-500">
                  {new Date(o.createdAt).toLocaleString()} · {o.paymentId || "—"}
                </p>
                <p className="text-xs text-gray-400">
                  {o.items.map((i) => `${i.product.name}×${i.quantity}`).join(", ")}
                </p>
              </div>
            ))
          )}
        </div>
      )}

      {/* Add product */}
      {tab === "add" && (
        <form onSubmit={handleAdd} className="glass rounded-2xl p-6 space-y-4 max-w-lg">
          <div>
            <label className="block text-xs text-gray-400 mb-1">Name</label>
            <input
              required
              value={newProd.name}
              onChange={(e) => setNewProd({ ...newProd, name: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Description</label>
            <textarea
              value={newProd.description}
              onChange={(e) => setNewProd({ ...newProd, description: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm"
              rows={2}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Category</label>
              <select
                value={newProd.category}
                onChange={(e) => setNewProd({ ...newProd, category: e.target.value as Category })}
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm"
              >
                {Object.entries(categoryLabels).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Emoji / Image</label>
              <input
                value={newProd.image}
                onChange={(e) => setNewProd({ ...newProd, image: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Price (₹)</label>
              <input
                type="number"
                required
                value={newProd.price}
                onChange={(e) => setNewProd({ ...newProd, price: Number(e.target.value) })}
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Original Price (₹)</label>
              <input
                type="number"
                value={newProd.originalPrice}
                onChange={(e) => setNewProd({ ...newProd, originalPrice: Number(e.target.value) })}
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-purple-500/30 text-white text-sm"
              />
            </div>
          </div>
          <button type="submit" className="btn-primary w-full py-3 rounded-xl text-white font-semibold text-sm">
            Add Product
          </button>
        </form>
      )}
    </div>
  );
}
