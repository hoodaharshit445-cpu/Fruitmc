import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { StoreProvider } from "@/context/StoreContext";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "FruitMC — Premium Minecraft Store",
  description: "Unlock exclusive ranks, perks and rewards on FruitMC. play.fruitmc.fun",
  keywords: ["minecraft", "fruitmc", "ranks", "crates", "server store"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased mc-bg min-h-screen flex flex-col`}>
        <StoreProvider>
          <Navbar />
          <main className="flex-1 pt-16 md:pt-[72px]">{children}</main>
          <Footer />
        </StoreProvider>
      </body>
    </html>
  );
}
