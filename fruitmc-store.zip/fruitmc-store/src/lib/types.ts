export type Category = "ranks" | "crates" | "coins" | "special";

export interface Product {
  id: string;
  name: string;
  description: string;
  category: Category;
  price: number;
  originalPrice: number;
  discount: number;
  image: string; // emoji or icon key
  features?: string[];
  popular?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  status: "pending" | "completed" | "failed";
  username: string;
  createdAt: string;
  paymentId?: string;
}

export interface User {
  id: string;
  email: string;
  username: string; // Minecraft username
  orders: Order[];
}
